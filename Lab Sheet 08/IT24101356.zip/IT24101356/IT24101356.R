setwd("C:\\Users\\it24101356\\Desktop\\IT24101356")
getwd()
data<-read.table("Data - Lab 8.txt",header = TRUE)
fix(data)