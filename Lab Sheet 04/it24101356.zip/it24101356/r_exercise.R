#import
branch_data<-read.csv("Exercise.txt",header =TRUE )

#check data
head(branch_data)

#3
str(branch_data)

#boxplot for sales
boxplot(branch_data$Sales_X1,
        outline = TRUE,
        outpch=8,
        horizontal = TRUE,
        main="sales ditribution")

#4
summary(branch_data$Advertising_X2)
IQR_advertising<-IQR(branch_data$Advertising_X2)
IQR_advertising

#5
find_outliers <- function(years) {
  # Calculate quantiles
  Q1 <- quantile(years)[2]
  Q3 <- quantile(years)[4]
  
  # Calculate IQR
  IQR <- Q3 - Q1
  
  # Lower and upper bounds
  lower <- Q1 - 1.5 * IQR
  upper <- Q3 + 1.5 * IQR
  
  # Find outliers
  outliers <- years[years < lower | years > upper]
  outliers <- sort(outliers)
  
  # Print the bounds
  cat("Lower Bound: ", lower, "\n")
  cat("Upper Bound: ", upper, "\n")
  cat("Outliers: ", outliers, "\n")
  
  return(outliers)
}

# Detect outliers
outliers_years <- find_outliers(branch_data$Years)
